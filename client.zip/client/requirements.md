## Packages
framer-motion | Smooth animations and scroll reveals
react-icons | Font Awesome icons for skills section (FaCode, FaPaintBrush, etc.)
react-scroll | Smooth scrolling for navigation links

## Notes
Skills endpoint: GET /api/skills
Contact endpoint: POST /api/contact
Expects specific icon names (FaCode, etc.) from the skills API to render correct react-icons
